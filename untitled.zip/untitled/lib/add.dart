import'package:flutter/material.dart';

class add extends StatelessWidget {
    @override
    Widget build(BuildContext context) {
        return Scaffold(
          appBar: AppBar(
              title: Text("Add Note"),
          ),
          body:TextFormField(
              maxLength: 30,
              decoration: InputDecoration(
                icon: Icon(Icons.note),hintText: "add note",
                  // label: Container(child:Text("evwv")
              ),



          )
        );
    }
}