import 'package:flutter/material.dart';
import 'package:untitled/add.dart';
import 'package:untitled/homapage.dart';
import 'package:untitled/one.dart';
import 'package:untitled/test.dart';
void main() {
  runApp(MYapp());
}

class MYapp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home:Scaffold(
          appBar: AppBar(),
        ),
        routes: {
          "signup":(context)=>signup(),
          "homepages":(context) =>homepage(),
          "add":(context) =>add(),
        }
    );
  }
}

